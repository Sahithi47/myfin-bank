-- 1. Create Database
create database TechNovaDB;
use TechNovaDB;

-- 2. Create department table
create table department(deptid int primary key,
deptname varchar(30) not null unique,
loaction varchar(30) not null);

-- 3. Create Emloyee Table
create table employee(empid int primary key,
empname varchar(50) not null, gender enum('M', 'F', 'other'),
dob date not null, hiredate date not null,
deptid int, foreign key (deptid) references department(deptid)
on delete set null on update cascade);

-- 4. Create Project Table
create table project(projid int primary key,
projname varchar(50) not null, deptid int, startdate date,
enddate date, foreign key(deptid) references department(deptid)
on delete cascade);

-- 5. Create Perdormance table
create table performance(empid int, projid int, rating decimal(3,1)
check (rating between 1 and 5), reviewdate date, primary key(empid,projid),
foreign key(empid) references employee(empid) on delete cascade,
foreign key (projid) references project(projid) on delete cascade);

-- 6. Create Reward table
create table reward(empid int, rewardmonth date,rewardamount decimal(10,2) check 
(rewardamount>=0), primary key(empid, rewardmonth), 
foreign key (empid) references employee(empid) on delete cascade);

-- 7. create indexes
create index idx_empname on employee(empname);
create index idx_depid on employee(deptid);

-- USER STORY - 2
-- insert departments
insert into department values(101, 'IT', 'Banglore'),
(102, 'HR', 'Delhi'), (103, 'finance', 'Mumbai'),
(104, 'Marketing', 'Hyderabad'), (105, 'Operations', 'Chennai');

-- insert employees
insert into employee values(1, 'Asha', 'F', '1990-07-12','2018-06-10', 101),
(2, 'Raj', 'M', '1988-04-09', '2020-03-22', 102),
(3, 'Neha', 'F', '1995-01-15', '2021-01-15', 101),
(4, 'Karan', 'M', '1992-11-25', '2019-02-14', 103),
(5, 'Priya', 'F', '1993-05-18', '2022-01-10', 104);

-- insert projects
insert into project values(201, 'ERP System', 101, '2023-01-01', '2023-12-31'),
(202, 'HR Portal', 102, '2023-02-01', '2023-10-30'),
(203, 'Finance Audit', 103, '2023-03-01', '2023-09-30'),
(204, 'Marketing Campaign', 104, '2023-04-01', '2023-11-30'),
(205, 'Logistics App', 105, '2023-05-01', '2023-12-15');

-- insert performance
insert into performance values(1,201,4.5,'2023-06-15'),
(2,202,4.0,'2023-07-10'), (3,201,4.8,'2023-08-20'),
(4,203,3.9,'2023-09-12'), (5,204,4.2,'2023-10-05');

-- Insert Rewards
insert into Reward values(1,'2024-01-01',2500),
(2,'2024-02-01',1800), (3,'2024-03-01',3000),
(4,'2024-04-01',900), (5,'2024-05-01',2200);

-- Update one employee’s department
update Employee set DeptID = 103 where EmpID = 2;

-- Delete reward where amount < 1000
delete from Reward where RewardAmount < 1000;

-- USER STORY - 3
-- 1. Employees who joined after 2019-01-01
select * from Employee where HireDate > '2019-01-01';

-- 2. Average performance rating per department
select d.DeptName, AVG(p.Rating) as AvgRating from Department d JOIN Employee e on d.DeptID = e.DeptID 
join Performance p on e.EmpID = p.EmpID GROUP BY d.DeptName;

-- 3. Employees with Age
select EmpName, TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age from Employee;

-- 4. Total rewards in current year
select SUM(RewardAmount) AS TotalRewards from Reward where year(RewardMonth) = YEAR(CURDATE());

-- 5. Employees with rewards > 2000
select e.EmpName, r.RewardAmount from Employee e join Reward r on e.EmpID = r.EmpID
where r.RewardAmount > 2000;

-- USER STORY - 4
-- 1. Display Employee Name, Department Name, Project Name, and Rating using appropriate joins.
select e.empname, d.deptname, pr.projname, p.rating from employee e join department d on
e.deptid = d.deptid join performance p on e.empid = p.empid
join project pr on p.projid = pr.projid;

-- 2. Find the highest-rated employee in each department using a subquery. 
select e.empname, d.deptname, p.rating from employee e join department d on e.deptid = d.deptid
join performance p on e.empid = p.empid where p.rating = (select MAX(p2.rating) from performance p2
join employee e2 on p2.empid = e2.empid where e2.deptid = e.deptid);

-- 3. List all employees who have not received any rewards using a subquery.
select empname from employee where empid not in (select empid from reward);

-- USER STORY - 5
start transaction;

insert into Employee values(6, 'Arjun', 'M', '1996-03-12', '2024-01-15', 101);

insert into Performance values(6, 201, 4.3, '2024-02-10');

commit;
-- If error occurs
-- roolback;

explain select e.empname, d.deptname, p.rating from employee e
join department d on e.deptid = d.deptid join performance p on e.empid = p.empid;

-- BONUS
/* 1. Create a view named EmployeePerformanceView combining Employee, Department, and 
Performance data.*/
create view EmployeePerformanceView as 
select e.empname, d.deptname, p.projid, p.rating from employee e
join department d on e.deptid = d.deptid 
join performance p on e.empid = p.empid;

/* 2. Create a stored procedure named GetTopPerformers(deptName) that returns the top 3 
employees in that department based on their performance rating.*/
DELIMITER $$ 
create procedure GetTopPerformers(in deptname varchar(50))
begin select e.empname, p.rating from Employee e
join Department d on e.deptid = d.deptid
join performance p on e.empid = p.empid where d.deptname = deptname
order by p.rating desc limit 3;
END $$ 
DELIMITER ;
