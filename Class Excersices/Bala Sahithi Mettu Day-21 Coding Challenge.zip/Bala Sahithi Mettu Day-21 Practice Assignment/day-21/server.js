const express = require("express");
const app = express();

// middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// logging middleware
app.use((req, res, next) => {
  const time = new Date().toISOString();
  console.log(`[${req.method}] ${req.url} at ${time}`);
  next();
});

// set view engine
app.set("view engine", "ejs");

// home route
app.get("/", (req, res) => {
  res.send("Welcome to SkillSphere LMS API");
});

// users route
app.post("/users", (req, res) => {
  const userData = req.body;

  res.json({
    message: "User created successfully",
    data: userData
  });
});

// courses route
app.get("/courses", (req, res) => {

  const courses = [
    "ReactJS",
    "NodeJS",
    "MongoDB",
    "ExpressJS"
  ];

  res.render("courses", { courses });
});

app.listen(4000, () => {
  console.log("Server running at http://localhost:4000");
});