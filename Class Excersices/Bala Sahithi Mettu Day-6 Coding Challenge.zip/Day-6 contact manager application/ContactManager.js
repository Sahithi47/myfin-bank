// ContactManager class
var ContactManager = /** @class */ (function () {
    function ContactManager() {
        this.contacts = [];
    }
    // Add a new contact
    ContactManager.prototype.addContact = function (contact) {
        var alreadyExists = this.contacts.some(function (c) { return c.id === contact.id; });
        if (alreadyExists) {
            console.error("Error: Contact with ID ".concat(contact.id, " already exists."));
            return;
        }
        this.contacts.push(contact);
        console.log("Success: Contact \"".concat(contact.name, "\" added."));
    };
    // View all contacts
    ContactManager.prototype.viewContacts = function () {
        if (this.contacts.length === 0) {
            console.log("No contacts found.");
        }
        return this.contacts;
    };
    // Modify existing contact
    ContactManager.prototype.modifyContact = function (id, updatedContact) {
        var contact = this.contacts.find(function (c) { return c.id === id; });
        if (!contact) {
            console.error("Error: Contact with ID ".concat(id, " does not exist."));
            return;
        }
        Object.assign(contact, updatedContact);
        console.log("Success: Contact with ID ".concat(id, " updated."));
    };
    // Delete a contact
    ContactManager.prototype.deleteContact = function (id) {
        var index = this.contacts.findIndex(function (c) { return c.id === id; });
        if (index === -1) {
            console.error("Error: Contact with ID ".concat(id, " not found."));
            return;
        }
        var removedContact = this.contacts.splice(index, 1);
        console.log("Success: Contact \"".concat(removedContact[0].name, "\" deleted."));
    };
    return ContactManager;
}());
// ---------------- TESTING SCRIPT ----------------
var manager = new ContactManager();
// Add contacts
manager.addContact({
    id: 1,
    name: "Ananya Rao",
    email: "ananya.rao@mail.com",
    phone: "9876543210"
});
manager.addContact({
    id: 2,
    name: "Rahul Mehta",
    email: "rahul.mehta@mail.com",
    phone: "9123456780"
});
// View contacts
console.log("Contact List:", manager.viewContacts());
// Modify contact
manager.modifyContact(1, {
    phone: "9999999999"
});
// Try modifying non-existing contact
manager.modifyContact(5, {
    name: "Unknown User"
});
// Delete contact
manager.deleteContact(2);
// Try deleting non-existing contact
manager.deleteContact(10);
// Final list
console.log("Final Contact List:", manager.viewContacts());
