// Interface definition
interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}

// ContactManager class
class ContactManager {
    private contacts: Contact[] = [];

    // Add a new contact
    addContact(contact: Contact): void {
        const alreadyExists = this.contacts.some(c => c.id === contact.id);

        if (alreadyExists) {
            console.error(`Error: Contact with ID ${contact.id} already exists.`);
            return;
        }

        this.contacts.push(contact);
        console.log(`Success: Contact "${contact.name}" added.`);
    }

    // View all contacts
    viewContacts(): Contact[] {
        if (this.contacts.length === 0) {
            console.log("No contacts found.");
        }
        return this.contacts;
    }

    // Modify existing contact
    modifyContact(id: number, updatedContact: Partial<Contact>): void {
        const contact = this.contacts.find(c => c.id === id);

        if (!contact) {
            console.error(`Error: Contact with ID ${id} does not exist.`);
            return;
        }

        Object.assign(contact, updatedContact);
        console.log(`Success: Contact with ID ${id} updated.`);
    }

    // Delete a contact
    deleteContact(id: number): void {
        const index = this.contacts.findIndex(c => c.id === id);

        if (index === -1) {
            console.error(`Error: Contact with ID ${id} not found.`);
            return;
        }

        const removedContact = this.contacts.splice(index, 1);
        console.log(`Success: Contact "${removedContact[0].name}" deleted.`);
    }
}

// ---------------- TESTING SCRIPT ----------------

const manager = new ContactManager();

// Add contacts
manager.addContact({
    id: 1,
    name: "Ananya Rao",
    email: "ananya.rao@mail.com",
    phone: "9876543210"
});

manager.addContact({
    id: 2,
    name: "Rahul Mehta",
    email: "rahul.mehta@mail.com",
    phone: "9123456780"
});

// View contacts
console.log("Contact List:", manager.viewContacts());

// Modify contact
manager.modifyContact(1, {
    phone: "9999999999"
});

// Try modifying non-existing contact
manager.modifyContact(5, {
    name: "Unknown User"
});

// Delete contact
manager.deleteContact(2);

// Try deleting non-existing contact
manager.deleteContact(10);

// Final list
console.log("Final Contact List:", manager.viewContacts());