const fs = require('fs');
const fsPromises = fs.promises;
const path = require('path');

// Challenge 8: Promises
// User Story: Chain multiple async operations using Promises
// Expected Outcome: Read input.txt → Write to output.txt with chained Promises

console.log('=== Challenge 8: Promises ===\n');

// Create input.txt file for testing
const inputFilePath = path.join(__dirname, 'input.txt');
const outputFilePath = path.join(__dirname, 'output.txt');
const inputData = 'This is the content from input.txt that will be copied to output.txt using Promises.\nPromises allow chaining without callback nesting!';

// Write input.txt first
fs.writeFileSync(inputFilePath, inputData);
console.log('input.txt created for testing.\n');

// Promise chain for file copy operation
console.log('Starting file copy operation using Promises...\n');

fsPromises.readFile(inputFilePath, 'utf8')
  .then((data) => {
    console.log('Step 1: File read successfully!');
    console.log('Content preview:', data.substring(0, 50) + '...\n');
    
    // Chain the write operation
    return fsPromises.writeFile(outputFilePath, data);
  })
  .then(() => {
    console.log('Step 2: Content written to output.txt successfully!\n');
    
    // Verify the write by reading output.txt
    return fsPromises.readFile(outputFilePath, 'utf8');
  })
  .then((data) => {
    console.log('Step 3: Verification - Content from output.txt:');
    console.log('---');
    console.log(data);
    console.log('---\n');
    console.log('File copied successfully!');
    console.log('Operation completed at:', new Date().toLocaleTimeString());
  })
  // Error handling (Bonus requirement)
  .catch((err) => {
    console.error('Error during file operations:', err.message);
    console.error('Error code:', err.code);
  })
  .finally(() => {
    console.log('\nPromise chain completed (finally block)');
  });