const fs = require('fs');
const fsPromises = fs.promises;
const path = require('path');

// Challenge 9: Async/Await
// User Story: Clean syntax for asynchronous operations using async/await
// Expected Outcome: Convert to async/await with try/catch for error handling

console.log('=== Challenge 9: Async/Await ===\n');

// Create input file for this challenge
const inputFilePath = path.join(__dirname, 'input-async.txt');
const outputFilePath = path.join(__dirname, 'output-async.txt');
const inputData = 'This is content for the async/await challenge.\nAsync/await provides cleaner syntax compared to .then() chains.\nIt makes asynchronous code look like synchronous code!';

// Write input file first
fs.writeFileSync(inputFilePath, inputData);
console.log('input-async.txt created for testing.\n');

// Main async function demonstrating the file copy operation
async function copyFileWithAsyncAwait() {
  try {
    console.log('Starting file copy operation using async/await...\n');
    
    // Step 1: Read the input file
    console.log('Step 1: Reading from input-async.txt...');
    const data = await fsPromises.readFile(inputFilePath, 'utf8');
    console.log('File read successfully!');
    console.log('Content preview:', data.substring(0, 50) + '...\n');
    
    // Bonus: Add artificial delay to simulate slow operation
    console.log('Step 2: Adding artificial delay (simulating slow operation)...');
    await new Promise(res => setTimeout(res, 1000));
    console.log('Delay completed (1000ms).\n');
    
    // Step 3: Write to output file
    console.log('Step 3: Writing to output-async.txt...');
    await fsPromises.writeFile(outputFilePath, data);
    console.log('File written successfully!\n');
    
    // Step 4: Verify the operation by reading output file
    console.log('Step 4: Verification - Reading output-async.txt...');
    const verifyData = await fsPromises.readFile(outputFilePath, 'utf8');
    console.log('Content from output-async.txt:');
    console.log('---');
    console.log(verifyData);
    console.log('---\n');
    
    // Success message
    console.log('✓ File copied successfully!');
    console.log('Operation completed at:', new Date().toLocaleTimeString());
    
  } catch (err) {
    // Graceful error handling (Bonus requirement)
    console.error('❌ Error occurred during file operation:');
    console.error('Error message:', err.message);
    console.error('Error code:', err.code);
    console.error('Error timestamp:', new Date().toLocaleTimeString());
  } finally {
    console.log('\nAsync/await operation finished (finally block executed)');
  }
}

// Execute the async function
copyFileWithAsyncAwait();