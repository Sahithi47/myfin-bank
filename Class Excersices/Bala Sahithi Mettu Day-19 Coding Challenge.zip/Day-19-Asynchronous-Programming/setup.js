// Day 18 — Asynchronous Programming in Node.js
// Complete Assignment: Challenges 7, 8, and 9

console.log('╔════════════════════════════════════════════════════════╗');
console.log('║  Day 18: Asynchronous Programming in Node.js         ║');
console.log('║  Challenges 7, 8, and 9 - Complete Assignment        ║');
console.log('╚════════════════════════════════════════════════════════╝\n');

console.log('This assignment covers three asynchronous patterns:\n');
console.log('Challenge 7: Callbacks - Traditional callback-based async');
console.log('Challenge 8: Promises - Promise-based chaining');
console.log('Challenge 9: Async/Await - Modern clean syntax\n');

console.log('To run each challenge, execute:\n');
console.log('  node challenge7-callbacks.js');
console.log('  node challenge8-promises.js');
console.log('  node challenge9-async-await.js\n');

console.log('All challenges create temporary test files:');
console.log('  - Challenge 7: data.txt');
console.log('  - Challenge 8: input.txt, output.txt');
console.log('  - Challenge 9: input-async.txt, output-async.txt\n');