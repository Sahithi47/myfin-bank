const fs = require('fs');
const path = require('path');

// Challenge 7: Callbacks
// User Story: Read a file and display a confirmation message using callbacks
// Expected Outcome: Demonstrate asynchronous behavior with callbacks

console.log('=== Challenge 7: Callbacks ===\n');

// Create data.txt file for testing
const dataFilePath = path.join(__dirname, 'data.txt');
const sampleData = 'This is sample data for the callback challenge.\nIt demonstrates asynchronous file reading.';

// First, write the data.txt file
fs.writeFile(dataFilePath, sampleData, (writeErr) => {
  if (writeErr) {
    console.error('Error writing file:', writeErr);
    return;
  }
  
  console.log('data.txt file created for testing.\n');
  
  // Now demonstrate the callback-based file reading
  console.log('Starting file read operation (asynchronous)...');
  console.log('This line executes BEFORE the file is read (demonstrates async behavior)\n');
  
  // Callback function for file reading
  const readCallback = (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      return;
    }
    
    // Add intentional delay using setTimeout (Bonus requirement)
    setTimeout(() => {
      console.log('File content read:');
      console.log('---');
      console.log(data);
      console.log('---\n');
      console.log('Read operation completed');
      console.log('Timestamp:', new Date().toLocaleTimeString());
    }, 1000);
  };
  
  // Read file using callback
  fs.readFile(dataFilePath, 'utf8', readCallback);
  
  // This executes immediately, showing async behavior
  console.log('File read initiated (callback registered, not yet executed)\n');
});