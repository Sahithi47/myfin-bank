const EventEmitter = require("events");

const eventEmitter = new EventEmitter();

eventEmitter.on("userLoggedIn", (name) => {
  console.log(`User ${name} logged in.`);
});

eventEmitter.on("userLoggedOut", (name) => {
  console.log(`User ${name} logged out.`);
});

eventEmitter.emit("userLoggedIn", "John");
eventEmitter.emit("userLoggedOut", "John");

setTimeout(() => {
  eventEmitter.emit("sessionExpired");
}, 5000);

eventEmitter.on("sessionExpired", () => {
  console.log("Session expired.");
});