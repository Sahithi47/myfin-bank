const fs = require("fs").promises;

async function fileOperation() {
  try {
    const feedback = "Node.js is awesome!";

    await fs.writeFile("feedback.txt", feedback);

    console.log("Data written successfully.");
    console.log("Reading file...");

    const data = await fs.readFile("feedback.txt", "utf8");

    console.log(data);
  } catch (error) {
    console.log(error);
  }
}

fileOperation();