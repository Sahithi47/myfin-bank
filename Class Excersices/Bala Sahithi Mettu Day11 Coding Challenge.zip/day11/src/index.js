import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import BookStore from "./flux/stores/BookStore";
import Dispatcher from "./flux/dispatcher/AppDispatcher";

const store = new BookStore();
Dispatcher.register(store.handleActions.bind(store));

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App bookStore={store} />
  </React.StrictMode>
);