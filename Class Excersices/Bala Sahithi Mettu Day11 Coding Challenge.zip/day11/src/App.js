import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { useState } from "react";
import BookList from "./components/BookList";
import AddBookForm from "./components/AddBookForm";
import "./App.css";

function App() {
  const [books, setBooks] = useState([]);

  const addBook = (newBook) => {
    setBooks([...books, newBook]);
  };

  return (
    <BrowserRouter>
      <div className="navbar">
        <Link to="/">Home</Link>
        <Link to="/add">Add Book</Link>
      </div>

      <div className="container">
        <Routes>
          <Route path="/" element={<BookList books={books} />} />
          <Route path="/add" element={<AddBookForm addBook={addBook} />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;