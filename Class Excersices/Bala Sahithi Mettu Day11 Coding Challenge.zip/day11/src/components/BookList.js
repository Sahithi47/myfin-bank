const BookList = ({ books }) => {
  return (
    <div>
      <h2> Book List</h2>

      {books.length === 0 ? (
        <p className="empty">No books added yet</p>
      ) : (
        books.map((book, index) => (
          <div className="card" key={index}>
            <h3>{book.title}</h3>
            <p><strong>Author:</strong> {book.author}</p>
            <p><strong>Price:</strong> ₹{book.price}</p>
          </div>
        ))
      )}
    </div>
  );
};

export default BookList;