class BookStore {
  constructor() {
    this.books = [];
    this.listeners = [];
  }

  getBooks() {
    return this.books;
  }

  addChangeListener(listener) {
    this.listeners.push(listener);
  }

  emitChange() {
    this.listeners.forEach(listener => listener());
  }

  handleActions(action) {
    switch (action.type) {
      case "ADD_BOOK":
        this.books.push(action.payload);
        this.emitChange();
        break;
      default:
        break;
    }
  }
}

export default BookStore;