const express = require("express");
const router = express.Router();

// Route: /courses/:id
router.get("/:id", (req, res) => {
  const id = req.params.id;

  res.json({
    id: id,
    name: "React Mastery",
    duration: "6 weeks"
  });
});

module.exports = router;