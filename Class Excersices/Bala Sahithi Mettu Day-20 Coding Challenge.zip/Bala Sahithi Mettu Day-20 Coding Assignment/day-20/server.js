const express = require("express");
const app = express();

const courseRoutes = require("./routes/courses");

// Root route
app.get("/", (req, res) => {
  res.send("Welcome to SkillSphere LMS API");
});

// Course routes
app.use("/courses", courseRoutes);

// Start server
app.listen(4000, () => {
  console.log("Server running at http://localhost:4000");
});