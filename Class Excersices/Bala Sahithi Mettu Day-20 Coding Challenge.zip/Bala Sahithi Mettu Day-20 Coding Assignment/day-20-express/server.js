const express = require('express');
const app = express();
const PORT = 4000;

app.use(express.json()); // Parse JSON request bodies

// Challenge 3: Custom Logger Middleware (applied globally)
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] [${req.method}] ${req.url}`);
  next();
});

// Challenge 1: Root route
app.get('/', (req, res) => {
  res.send('Welcome to Express Server');
});

// Challenge 1 Bonus: /status route
app.get('/status', (req, res) => {
  res.json({ server: 'running', uptime: 'OK' });
});

// Challenge 2: /products route with query params
app.get('/products', (req, res) => {
  const { name } = req.query;
  if (name) {
    res.json({ query: name }); // Bonus: JSON format
  } else {
    res.send('Please provide a product name');
  }
});

// Challenge 5: Modular /books routes
const bookRouter = require('./routes/books');
app.use('/books', bookRouter);

// Challenge 5: 404 Handler (must be AFTER all routes)
app.use((req, res, next) => {
  res.status(404).json({ error: 'Route not found' });
});

// Challenge 5 Bonus: Global Error Handler
app.use((err, req, res, next) => {
  console.error('Error:', err.message);
  res.status(500).json({ error: 'Internal Server Error' });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});