const moment = require("moment");

// Get name from command line
const name = process.argv[2];

// Current date and time
const now = moment().format("ddd MMM D YYYY, hh:mm A");

console.log(`Hello, ${name}! Today is ${now}`);