console.log("Node Version:", process.version);
console.log("File Name:", __filename);

// Current directory
console.log("Directory:", __dirname);

// Welcome message every 3 seconds
const timer = setInterval(() => {
    console.log("Welcome to Node.js!");
}, 3000);

// Stop after 10 seconds
setTimeout(() => {
    clearInterval(timer);
    console.log("Timer stopped after 10 seconds.");
}, 10000);