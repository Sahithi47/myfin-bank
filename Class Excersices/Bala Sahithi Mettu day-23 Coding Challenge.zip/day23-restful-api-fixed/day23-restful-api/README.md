# Day 23 — RESTful APIs & API Middleware

## Setup & Run

```bash
npm install
npm start
```

## API Endpoints

Base URL: `http://localhost:3000/api/v1/courses`

| Method | Endpoint       | Description        |
|--------|----------------|--------------------|
| GET    | /              | Get all courses    |
| GET    | /:id           | Get course by ID   |
| POST   | /              | Create new course  |
| PUT    | /:id           | Update a course    |
| DELETE | /:id           | Delete a course    |

## Test Examples

### Create a course
```bash
curl -X POST http://localhost:3000/api/v1/courses \
  -H "Content-Type: application/json" \
  -d '{"name": "Node.js Basics", "duration": 30}'
```

### Validation error (missing fields)
```bash
curl -X POST http://localhost:3000/api/v1/courses \
  -H "Content-Type: application/json" \
  -d '{"description": "missing name"}'
# Returns: { "error": "Course name is required" }
```

### Rate limit test (run 6 times fast)
```bash
for i in {1..6}; do curl http://localhost:3000/api/v1/courses; done
# 6th request returns: { "error": "Too many requests" }
```
