require("dotenv").config();
const express = require("express");
const rateLimiter = require("./middleware/rateLimiter");
const errorHandler = require("./middleware/errorHandler");
const courseRoutes = require("./routes/courses");

const app = express();
const PORT = process.env.PORT || 3000;

// ── Core Middleware ──────────────────────────────────────────
app.use(express.json());

// ── Rate Limiting (applied to all API routes) ────────────────
app.use("/api/", rateLimiter);

// ── Routes ───────────────────────────────────────────────────
app.use("/api/v1/courses", courseRoutes);

// ── 404 Handler ──────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

// ── Centralized Error Handler ─────────────────────────────────
app.use(errorHandler);

// ── Start Server ──────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
  console.log(`📚 Courses API: http://localhost:${PORT}/api/v1/courses`);
});
