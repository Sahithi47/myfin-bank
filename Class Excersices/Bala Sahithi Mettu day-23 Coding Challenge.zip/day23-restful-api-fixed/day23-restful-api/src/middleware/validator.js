const { body, validationResult } = require("express-validator");

// Validation rules for creating/updating a course
const courseValidationRules = [
  body("name")
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage("Course name is required")
    .isString()
    .withMessage("Course name must be a string")
    .trim()
    .notEmpty()
    .withMessage("Course name is required"),

  body("duration")
    .exists({ checkNull: true })
    .withMessage("Duration is required")
    .custom((value) => {
      if (value === undefined || value === null || value === "") {
        throw new Error("Duration is required");
      }
      if (isNaN(Number(value))) {
        throw new Error("Duration must be a number");
      }
      return true;
    }),
];

// Middleware to check validation results
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: errors.array()[0].msg });
  }
  next();
};

module.exports = { courseValidationRules, validate };
