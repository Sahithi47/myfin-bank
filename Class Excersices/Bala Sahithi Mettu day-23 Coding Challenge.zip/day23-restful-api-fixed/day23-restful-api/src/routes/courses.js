const express = require("express");
const router = express.Router();
const { courseValidationRules, validate } = require("../middleware/validator");

// In-memory course store
let courses = [];
let nextId = 1;

// GET /api/v1/courses — Retrieve all courses
router.get("/", (req, res) => {
  res.status(200).json({ success: true, data: courses });
});

// GET /api/v1/courses/:id — Retrieve a single course
router.get("/:id", (req, res, next) => {
  const course = courses.find((c) => c.id === parseInt(req.params.id));
  if (!course) {
    const err = new Error("Course not found");
    err.status = 404;
    return next(err);
  }
  res.status(200).json({ success: true, data: course });
});

// POST /api/v1/courses — Create a new course (with validation)
router.post("/", courseValidationRules, validate, (req, res) => {
  const { name, duration, description } = req.body;
  const newCourse = {
    id: nextId++,
    name,
    duration,
    description: description || "",
    createdAt: new Date().toISOString(),
  };
  courses.push(newCourse);
  res.status(201).json({ success: true, data: newCourse });
});

// PUT /api/v1/courses/:id — Update a course (with validation)
router.put("/:id", courseValidationRules, validate, (req, res, next) => {
  const index = courses.findIndex((c) => c.id === parseInt(req.params.id));
  if (index === -1) {
    const err = new Error("Course not found");
    err.status = 404;
    return next(err);
  }
  const { name, duration, description } = req.body;
  courses[index] = {
    ...courses[index],
    name,
    duration,
    description: description || courses[index].description,
    updatedAt: new Date().toISOString(),
  };
  res.status(200).json({ success: true, data: courses[index] });
});

// DELETE /api/v1/courses/:id — Delete a course
router.delete("/:id", (req, res, next) => {
  const index = courses.findIndex((c) => c.id === parseInt(req.params.id));
  if (index === -1) {
    const err = new Error("Course not found");
    err.status = 404;
    return next(err);
  }
  const deleted = courses.splice(index, 1);
  res.status(200).json({ success: true, data: deleted[0] });
});

module.exports = router;
