function Loader() {
  return <div className="loader"> Loading books...</div>;
}

export default Loader;