import { useState } from "react";
import Loader from "./Loader";

const withLoader = (WrappedComponent) => {
  return function EnhancedComponent(props) {
    const [isLoading, setIsLoading] = useState(false);

    return (
      <>
        {isLoading && <Loader />}
        <WrappedComponent
          {...props}
          isLoading={isLoading}
          setIsLoading={setIsLoading}
        />
      </>
    );
  };
};

export default withLoader;