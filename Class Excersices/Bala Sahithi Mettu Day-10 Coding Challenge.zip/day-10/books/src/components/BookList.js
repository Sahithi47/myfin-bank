import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import withLoader from "./withLoader";
import StatusRenderer from "./StatusRenderer";

function BookList({ setIsLoading }) {
  const [books, setBooks] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    setIsLoading(true);
    fetch("http://localhost:3001/books")
      .then(res => res.json())
      .then(data => {
        setBooks(data);
        setIsLoading(false);
      });
  }, [setIsLoading]);

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page fade">
      <h2> BookVerse Library</h2>

      <StatusRenderer
        render={(status) => <p style={{ textAlign: "center" }}>{status}</p>}
        status={`Total Books Available: ${books.length}`}
      />

      <input
        type="text"
        placeholder=" Search book by title..."
        className="search-box"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {filteredBooks.length === 0 && (
        <p style={{ textAlign: "center", color: "red" }}>
          No books found
        </p>
      )}

      <ul className="book-list">
        {filteredBooks.map(book => (
          <li key={book.id} className="book-card">
            <Link to={`/book/${book.id}`}>{book.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default withLoader(BookList);