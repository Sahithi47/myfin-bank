function StatusRenderer({ render, status }) {
  return <>{render(status)}</>;
}

export default StatusRenderer;