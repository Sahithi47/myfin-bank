import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import withLoader from "./withLoader";

function BookDetails({ setIsLoading }) {
  const { id } = useParams();
  const [book, setBook] = useState(null);

  useEffect(() => {
    setIsLoading(true);
    fetch(`http://localhost:3001/books/${id}`)
      .then(res => res.json())
      .then(data => {
        setBook(data);
        setIsLoading(false);
      });
  }, [id, setIsLoading]);

  if (!book) return null;

  return (
    <div className="page fade">
      <h2>{book.title}</h2>
      <p><strong>Author:</strong> {book.author}</p>
      <p>{book.description}</p>

      <Link to="/home" className="back-link">
         Back to Library
      </Link>
    </div>
  );
}

export default withLoader(BookDetails);