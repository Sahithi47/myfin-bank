import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

export const fetchProducts = createAsyncThunk(
  "products/fetchProducts",
  async () => {
    return [
      { id: 1, title: "React Fundamentals" },
      { id: 2, title: "React Hooks" },
      { id: 3, title: "Context API & Global State" },
    ];
  }
);

const productSlice = createSlice({
  name: "products",
  initialState: { items: [] },
  reducers: {
    updateProduct: (state, action) => {
      const index = state.items.findIndex(
        (item) => item.id === action.payload.id
      );
      if (index !== -1) {
        state.items[index].title = action.payload.title;
      }
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchProducts.fulfilled, (state, action) => {
      state.items = action.payload;
    });
  },
});

export const { updateProduct } = productSlice.actions;
export default productSlice.reducer;