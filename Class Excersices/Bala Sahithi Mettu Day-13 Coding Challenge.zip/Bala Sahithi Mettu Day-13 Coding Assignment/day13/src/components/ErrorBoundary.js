import React, { Component } from "react";

class ErrorBoundary extends Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    console.error("Error logged:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return <h3 style={{ color: "red" }}>Something went wrong.</h3>;
    }
    return this.props.children;
  }
}

export default ErrorBoundary;