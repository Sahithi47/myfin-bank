import React, { useState } from "react";
import { useTimer } from "../hooks/useTimer";

function WorkoutTracker() {
  const [sets, setSets] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const { seconds, setSeconds } = useTimer(isRunning);

  const completeSet = () => {
    setSets((prev) => prev + 1);
    setSeconds(0);
  };

  return (
    <div className="card">
      <h3>Workout Tracker</h3>
      <p>Sets Completed: {sets}</p>
      <p>Rest Timer: {seconds} sec</p>

      <button onClick={completeSet}>Complete Set</button>
      <button onClick={() => setIsRunning(!isRunning)}>
        {isRunning ? "Stop Timer" : "Start Timer"}
      </button>
    </div>
  );
}

export default WorkoutTracker;