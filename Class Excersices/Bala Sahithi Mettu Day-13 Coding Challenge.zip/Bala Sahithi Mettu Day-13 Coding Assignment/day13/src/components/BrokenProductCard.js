export default function BrokenComponent() {
  throw new Error("This is a test error!");
}