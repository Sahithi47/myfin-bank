import React from "react";
import ReactDOM from "react-dom";
import "../styles/Modal.css";

function Modal({ onClose }) {
  return ReactDOM.createPortal(
    <div className="modal-overlay">
      <div className="modal">
        <h3>Notification</h3>
        <p>This is a portal modal.</p>
        <button onClick={onClose}>Close</button>
      </div>
    </div>,
    document.getElementById("modal-root")
  );
}

export default Modal;