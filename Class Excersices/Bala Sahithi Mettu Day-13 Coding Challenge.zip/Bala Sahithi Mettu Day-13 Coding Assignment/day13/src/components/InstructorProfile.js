import React from "react";
function InstructorProfile() {
  return (
    <div className="card">
      <h3>Instructor Profile</h3>

      <p>Instructor has 10+ years of experience.</p>
    </div>
  );
}

export default InstructorProfile;