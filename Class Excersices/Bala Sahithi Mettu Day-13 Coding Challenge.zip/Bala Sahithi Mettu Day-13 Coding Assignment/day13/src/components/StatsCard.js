import React from "react";

const StatsCard = React.memo(({ title, value, lastUpdated }) => {
  console.log(`${title} rendered`);

  return (
    <div className="card">
      <h4>{title}</h4>
      <p>{value}</p>
      <small>Updated: {lastUpdated}</small>
    </div>
  );
});

export default StatsCard;