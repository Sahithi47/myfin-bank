import React from "react";
function CourseDetails() {
  return (
    <div className="card">
      <h3>Course Details</h3>
      <p>This course covers advanced React concepts.</p>
    </div>
  );
}

export default CourseDetails;