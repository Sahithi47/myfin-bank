import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProducts, updateProduct } from "../redux/productSlice";

function ProductList() {
  const dispatch = useDispatch();
  const products = useSelector((state) => state.products.items);

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  return (
    <div className="card">
      <h3>Product List (Redux)</h3>

      {products.map((product) => (
        <div key={product.id} className="product-card">
          <p>{product.title}</p>
          <button
            onClick={() =>
              dispatch(
                updateProduct({
                  id: product.id,
                  title: "Updated Product",
                })
              )
            }
          >
            Update
          </button>
        </div>
      ))}
    </div>
  );
}

export default ProductList;