import React, { useState, Suspense, lazy, useContext } from "react";
import { ThemeProvider, ThemeContext } from "./context/ThemeContext";
import ThemeToggle from "./components/ThemeToggle";
import WorkoutTracker from "./components/WorkoutTracker";
import ProductList from "./components/ProductList";
import OfflineBanner from "./components/OfflineBanner";
import ErrorBoundary from "./components/ErrorBoundary";
import StatsCard from "./components/StatsCard";
import Modal from "./components/Modal";
import "./styles/App.css";

const CourseDetails = lazy(() => import("./components/CourseDetails"));
const InstructorProfile = lazy(() => import("./components/InstructorProfile"));

function AppContent() {
  const { theme } = useContext(ThemeContext);
  const [showCourse, setShowCourse] = useState(false);
  const [showInstructor, setShowInstructor] = useState(false);
  const [showModal, setShowModal] = useState(false);

  return (
    <div className={`app ${theme}`}>

  <OfflineBanner />

  <div className="main-container">

    {/* LEFT SIDE - DAY 12 */}
    <div className="column">
      <h2>Advanced React Concepts</h2>

      <button onClick={() => setShowCourse(true)}>Load Course</button>
      <button onClick={() => setShowInstructor(true)}>Load Instructor</button>

      <Suspense fallback={<p>Loading...</p>}>
        {showCourse && <CourseDetails />}
        {showInstructor && <InstructorProfile />}
      </Suspense>

      <ErrorBoundary>
        <StatsCard title="Users" value="100" lastUpdated="Today" />
      </ErrorBoundary>

      <button onClick={() => setShowModal(true)}>Open Modal</button>
      {showModal && <Modal onClose={() => setShowModal(false)} />}
    </div>

    {/* RIGHT SIDE - DAY 13 */}
    <div className="column">
      <h2>State Management & Hooks</h2>

      <ThemeToggle />
      <WorkoutTracker />
      <ProductList />
    </div>

  </div>
</div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;