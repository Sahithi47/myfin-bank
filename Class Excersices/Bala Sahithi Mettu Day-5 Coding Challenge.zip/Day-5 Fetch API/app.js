const BlogTodoApp = (function () {

    const POSTS_URL = "https://jsonplaceholder.typicode.com/posts";
    const TODOS_URL = "https://jsonplaceholder.typicode.com/todos";

    const postsDiv = document.getElementById("posts");
    const todosList = document.getElementById("todos");
    const postError = document.getElementById("postError");
    const todoError = document.getElementById("todoError");

    async function fetchData(url) {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error("Failed to fetch data");
        }
        return response.json();
    }

    function getCategory(id) {
        if (id % 3 === 0) return "Technology";
        if (id % 3 === 1) return "Education";
        return "Lifestyle";
    }

    function showPosts(posts) {
        postsDiv.innerHTML = "";

        posts.slice(0, 3).forEach((post, index) => {
            const card = document.createElement("div");
            card.className = "post";

            const title = `Blog Post ${index + 1}: Learning Made Simple`;
            const summary =
                "This post explains important concepts in a simple and easy-to-understand manner.";

            const fullText =
                `Written by Author ${post.userId}, this article belongs to the 
                ${getCategory(post.id)} category. It focuses on practical ideas 
                and real-world understanding rather than technical jargon.`;

            card.innerHTML = `
                <h3>${title}</h3>
                <p class="meta">Category: ${getCategory(post.id)} | Author ID: ${post.userId}</p>
                <p>${summary}</p>
                <button class="btn">Read More</button>
                <p class="hidden">${fullText}</p>
            `;

            const btn = card.querySelector(".btn");
            const hiddenText = card.querySelector(".hidden");

            btn.addEventListener("click", () => {
                hiddenText.style.display =
                    hiddenText.style.display === "none" ? "block" : "none";
            });

            postsDiv.appendChild(card);
        });
    }

    function showTodos(todos) {
        todosList.innerHTML = "";

        todos.slice(0, 5).forEach(todo => {
            const li = document.createElement("li");
            const status = todo.completed ? "Completed" : "Pending";
            li.textContent = `${status} - ${todo.title}`;
            todosList.appendChild(li);
        });
    }

    async function loadPosts() {
        try {
            const posts = await fetchData(POSTS_URL);
            showPosts(posts);
        } catch {
            postError.textContent = "Unable to load blog posts.";
        }
    }

    async function loadTodos() {
        try {
            const todos = await fetchData(TODOS_URL);
            showTodos(todos);
        } catch {
            todoError.textContent = "Unable to load todo list.";
        }
    }

    return {
        init() {
            loadPosts();
            loadTodos();
        }
    };

})();

BlogTodoApp.init();