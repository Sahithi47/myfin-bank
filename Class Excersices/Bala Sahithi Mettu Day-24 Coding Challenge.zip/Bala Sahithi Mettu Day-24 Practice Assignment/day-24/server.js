const express = require("express");
const multer = require("multer");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Serve static files
app.use("/materials", express.static(path.join(__dirname, "uploads")));
app.use(express.static(path.join(__dirname, "public")));

// Multer setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => {
    const sanitized = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, sanitized);
  },
});
const fileFilter = (req, file, cb) => {
  file.mimetype === "application/pdf" ? cb(null, true) : cb(new Error("Only PDFs allowed!"), false);
};
const upload = multer({ storage, fileFilter });

app.post("/upload", upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ message: "No file uploaded." });
  res.status(200).json({ message: `File uploaded successfully: ${req.file.filename}` });
});

// Track connected users
const onlineUsers = {};

io.on("connection", (socket) => {
  console.log(`✅ Connected: ${socket.id}`);

  // User joins with name and role
  socket.on("userJoined", ({ name, role }) => {
    onlineUsers[socket.id] = { name, role, socketId: socket.id };
    console.log(`👤 ${name} joined as ${role}`);

    // Notify everyone someone joined
    io.emit("systemMessage", `🔔 ${name} (${role}) joined the session`);

    // Send updated online users list to everyone
    io.emit("onlineUsers", Object.values(onlineUsers));
  });

  // Broadcast chat message to ALL users
  socket.on("chatMessage", ({ name, role, text }) => {
    console.log(`💬 [${role}] ${name}: ${text}`);
    io.emit("chatMessage", { socketId: socket.id, name, role, text });
  });

  // User disconnects
  socket.on("disconnect", () => {
    const user = onlineUsers[socket.id];
    if (user) {
      console.log(`❌ ${user.name} left`);
      io.emit("systemMessage", `🔴 ${user.name} (${user.role}) left the session`);
      delete onlineUsers[socket.id];
      io.emit("onlineUsers", Object.values(onlineUsers));
    }
  });
});

const PORT = 3000;
server.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));